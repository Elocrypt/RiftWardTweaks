
# Rift Ward Tweaks

**Version**: 2.0.0  
**Author**: Elocrypt  
**Game**: [Vintage Story](https://www.vintagestory.at)  
**ModDB Page**: https://mods.vintagestory.at/riftwardtweaks

## 📜 Overview

**Rift Ward Tweaks** is a lightweight server/client mod that introduces configuration options for Rift Wards.  
You can control both their **fuel consumption** and **blocking radius** to better suit your gameplay or server balance needs.

## ⚙️ Features

- 🔧 **Configurable Rift Blocking Range**  
  Increase or decrease how far a Rift Ward can block rift spawns.

- 🔋 **Fuel Consumption Multiplier**  
  Adjust how fast Rift Wards consume temporal gear energy.

- 🗃️ **Config File**: `riftwardtweaksconfig.json`  
  Located in your mod config folder, supports:
  ```json
  {
    "RiftBlockRange": 150,
    "FuelConsumptionMultiplier": 0.05
  }
* 📡 **Runtime Commands**
  Modify or reload the config without restarting the server.

## 💻 Admin Commands

All commands require the `controlserver` or `op` privilege:

| Command                  | Description                                                             |
| ------------------------ | ----------------------------------------------------------------------- |
| `/rwt reload`            | Reloads the config from disk.                                           |
| `/rwt get`               | Displays current config values.                                         |
| `/rwt set <key> <value>` | Updates a config value (`fuelconsumptionmultiplier`, `riftblockrange`). |

**Examples**:

```bash
/rwt set fuelconsumptionmultiplier 0.025
/rwt set riftblockrange 200
```

## 🧪 Compatibility

* ✅ Works in **singleplayer** and **multiplayer/server** modes.
* 🧩 Compatible with most other mods, as it only patches `BlockEntityRiftWard`.

## 🔧 Installation

1. Place the `.zip` file into your `Mods/` folder.
2. Start the game/server. A config will be generated if not found.
3. Customize `riftwardtweaksconfig.json` or use `/rwt set` in-game.

## 🧠 Notes

* The **effective runtime** now reflects the adjusted fuel multiplier.
* Rift blocking range is purely server-side; ensure clients are aware if balance is affected.
* This mod uses **Harmony patching**.

## ☕ Support

If you enjoy this mod and want to support development:
**[Ko-fi.com/elocrypt](https://ko-fi.com/elocrypt)**

---

